//
//  Text.swift
//  KNU_CSE
//
//  Created by junseok on 2021/07/17.
//

import Foundation

