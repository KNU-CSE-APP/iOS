//
//  SignInNavigationView.swift
//  KNU_CSE
//
//  Created by junseok on 2021/07/21.
//

import UIKit

class SignInNavigationView:UINavigationController{
   
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    override func viewDidLoad() {
        
    }
}
