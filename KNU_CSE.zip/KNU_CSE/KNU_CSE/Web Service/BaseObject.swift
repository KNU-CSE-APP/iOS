//
//  BaseObject.swift
//  MVVM_Practice
//
//  Created by junseok on 2021/07/09.
//

import Foundation

class BaseObject : Codable{
}
